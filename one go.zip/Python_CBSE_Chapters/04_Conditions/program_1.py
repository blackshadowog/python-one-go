# 04_Conditions
n=7
print('Even' if n%2==0 else 'Odd')
