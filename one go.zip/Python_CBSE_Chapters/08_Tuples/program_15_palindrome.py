# 08_Tuples example 15
s='madam'
print(s==s[::-1])
