# 08_Tuples example 5
s='madam'
print(s==s[::-1])
