# 12_Files
with open('demo.txt','w') as f:f.write('Hi')
