# 12_Files example 20
[print('*'*i) for i in range(1,6)]
