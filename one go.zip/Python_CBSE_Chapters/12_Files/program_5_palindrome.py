# 12_Files example 5
s='madam'
print(s==s[::-1])
