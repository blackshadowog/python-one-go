# 12_Files example 15
s='madam'
print(s==s[::-1])
