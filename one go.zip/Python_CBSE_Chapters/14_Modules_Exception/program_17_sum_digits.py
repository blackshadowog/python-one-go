# 14_Modules_Exception example 17
n=12345
print(sum(map(int,str(n))))
