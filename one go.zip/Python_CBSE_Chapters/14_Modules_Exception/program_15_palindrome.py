# 14_Modules_Exception example 15
s='madam'
print(s==s[::-1])
