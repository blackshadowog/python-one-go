# 14_Modules_Exception example 5
s='madam'
print(s==s[::-1])
