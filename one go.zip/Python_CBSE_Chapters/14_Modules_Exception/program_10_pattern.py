# 14_Modules_Exception example 10
[print('*'*i) for i in range(1,6)]
