# 14_Modules_Exception
try:
 print(10/0)
except Exception as e:
 print(e)
