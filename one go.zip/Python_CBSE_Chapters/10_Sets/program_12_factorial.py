# 10_Sets example 12
n=5
f=1
for i in range(1,n+1):f*=i
print(f)
