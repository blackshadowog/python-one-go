# 10_Sets example 15
s='madam'
print(s==s[::-1])
