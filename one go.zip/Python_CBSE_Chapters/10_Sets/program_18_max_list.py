# 10_Sets example 18
l=[3,9,1]
print(max(l))
