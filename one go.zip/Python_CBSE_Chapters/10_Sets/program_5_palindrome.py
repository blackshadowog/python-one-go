# 10_Sets example 5
s='madam'
print(s==s[::-1])
