# 10_Sets example 7
n=12345
print(sum(map(int,str(n))))
