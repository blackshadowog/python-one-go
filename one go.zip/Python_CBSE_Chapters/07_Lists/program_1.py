# 07_Lists
l=[5,2,9]
l.sort();print(l)
