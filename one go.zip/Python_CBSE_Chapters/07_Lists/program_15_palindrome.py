# 07_Lists example 15
s='madam'
print(s==s[::-1])
