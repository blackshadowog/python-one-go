# 13_OOP
class Student:
 def __init__(self,n): self.n=n
print(Student('A').n)
