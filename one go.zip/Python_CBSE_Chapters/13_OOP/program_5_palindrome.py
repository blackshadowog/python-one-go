# 13_OOP example 5
s='madam'
print(s==s[::-1])
