# 13_OOP example 15
s='madam'
print(s==s[::-1])
