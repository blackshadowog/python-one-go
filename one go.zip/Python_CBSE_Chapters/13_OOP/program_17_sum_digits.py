# 13_OOP example 17
n=12345
print(sum(map(int,str(n))))
