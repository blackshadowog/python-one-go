# 11_Functions example 15
s='madam'
print(s==s[::-1])
