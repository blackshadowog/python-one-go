# 09_Dictionaries example 15
s='madam'
print(s==s[::-1])
