# 09_Dictionaries example 11
n=7
[print(n,'x',i,'=',n*i) for i in range(1,11)]
