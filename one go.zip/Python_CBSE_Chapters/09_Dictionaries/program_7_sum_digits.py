# 09_Dictionaries example 7
n=12345
print(sum(map(int,str(n))))
