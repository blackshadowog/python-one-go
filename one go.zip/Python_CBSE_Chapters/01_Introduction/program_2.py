# 01_Introduction
print(sum([1,2,3]))
