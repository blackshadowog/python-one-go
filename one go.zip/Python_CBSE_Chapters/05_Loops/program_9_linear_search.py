# 05_Loops example 9
l=[1,4,7];x=4
print(x in l)
