# 06_Strings example 15
s='madam'
print(s==s[::-1])
