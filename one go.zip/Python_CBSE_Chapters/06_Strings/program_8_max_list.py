# 06_Strings example 8
l=[3,9,1]
print(max(l))
